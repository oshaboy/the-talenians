/**
 * (c) Copyright 2017, Daniel Gilor, All Rights Reserved
 */
// Building actions
export const BUILDING_INCREMENT_COUNT = 'BUILDING_INCREMENT_COUNT';
export const BUILDING_ADD_BUTTON = 'BUILDING_ADD_BUTTON';
export const BUILDING_SET_BUTTON = 'BUILDING_SET_BUTTON';
export const BUILDING_SET_INCREMENT = 'BUILDING_SET_INCREMENT';
export const BUILDING_INCREMENT_CONTRIBUTION = 'BUILDING_INCREMENT_CONTRIBUTION';
export const BUILDING_SET_CONTRIBUTION_PERCENT = 'BUILDING_SET_CONTRIBUTION_PERCENT';
// Counter actions
export const COUNTER_CASH_BUMP = 'COUNTER_CASH_BUMP';
export const COUNTER_SET_INCREMENT = 'COUNTER_SET_INCREMENT';
export const COUNTER_DEDUCT_COST = 'COUNTER_DEDUCT_COST';
// Skill actions
export const SKILL_SELECTED = 'SKILL_SELECTED';

export function buildingIncrementCount(id)
{
    return { type : BUILDING_INCREMENT_COUNT, id : id }
}

export function buildingAddButton(id, cost, increment, increment_percent)
{
    return { type : BUILDING_ADD_BUTTON, id : id, cost: cost, increment: increment, increment_percent : increment_percent }
}

export function buildingSetButton(id, cost, increment, increment_percent)
{
    return { type : BUILDING_SET_BUTTON, id : id, cost: cost, increment: increment, increment_percent : increment_percent }
}

export function buildingSetIncrement(id, increment)
{
    return { type : BUILDING_SET_INCREMENT, id : id, increment: increment }
}

export function buildingIncrementContribution(id, contributionIncrement)
{
    return { type : BUILDING_INCREMENT_CONTRIBUTION, id : id, contributionIncrement: contributionIncrement }
}

export function buildingSetContributionPercent(id, percent)
{
    return { type : BUILDING_SET_CONTRIBUTION_PERCENT, id : id, percent: percent }
}

export function counterCashBump(cashIncrement, newTick)
{
    return { type : COUNTER_CASH_BUMP, cashIncrement : cashIncrement, newTick : newTick }
}

export function counterSetIncrement(increment)
{
    return { type : COUNTER_SET_INCREMENT, increment : increment }
}

export function counterDeductCost(cost)
{
    return { type : COUNTER_DEDUCT_COST, cost : cost }
}

export function skillSelected(id)
{
    return { type : SKILL_SELECTED, id : id }
}
