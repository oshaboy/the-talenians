/**
 * (c) Copyright 2017, Daniel Gilor, All Rights Reserved
 */
import React, { PropTypes } from 'react'
import BuildingButton from './BuildingButton'

const BuildingButtonList = ({ building, onBuildingButtonClick }) => (
    <ul>
        {building.map(buildingButton =>
            <BuildingButton
                key={buildingButton.id}
                {...buildingButton}
                onClick={() => onBuildingButtonClick(buildingButton.id)}
            />
        )}
    </ul>
)

BuildingButtonList.propTypes = {
    building: PropTypes.arrayOf(PropTypes.shape({
        id: PropTypes.string.isRequired,
        count: PropTypes.number.isRequired,
        cost: PropTypes.number.isRequired,
        round_cost: PropTypes.number.isRequired,
        round_increment: PropTypes.number.isRequired,
        contribution: PropTypes.number.isRequired
    }).isRequired).isRequired,
    onBuildingButtonClick: PropTypes.func.isRequired
}

export default BuildingButtonList
