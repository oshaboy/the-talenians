/**
 * (c) Copyright 2017, Daniel Gilor, All Rights Reserved
 */
import React, { PropTypes } from 'react'
import SkillButton from './SkillButton'

const SkillButtonList = ({ skill, onSkillButtonClick }) => (
    <div className="SkillButtonList">
        {skill.map(skillButton =>
            <SkillButton
                key={skillButton.id}
                {...skillButton}
                onClick={() => onSkillButtonClick(skillButton.id)}
            />
        )}
    </div>
)

SkillButtonList.propTypes = {
    skill: PropTypes.arrayOf(PropTypes.shape({
        id: PropTypes.string.isRequired,
        selected: PropTypes.bool.isRequired,
        cost: PropTypes.number.isRequired,
        enabled: PropTypes.bool.isRequired
    }).isRequired).isRequired,
    onSkillButtonClick: PropTypes.func.isRequired
}

export default SkillButtonList
