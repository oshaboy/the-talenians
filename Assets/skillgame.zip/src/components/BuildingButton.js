/**
 * (c) Copyright 2017, Daniel Gilor, All Rights Reserved
 */
import React, { PropTypes } from 'react'

const BuildingButton = ({ onClick, count, round_cost, round_increment, percent }) => (
    <li>
        <button onClick={onClick}>
            {count} Cost={round_cost} Increment={round_increment} {percent}%
        </button>
    </li>
)

BuildingButton.propTypes = {
    onClick: PropTypes.func.isRequired,
    count: PropTypes.number.isRequired,
    cost: PropTypes.number.isRequired,
    round_cost: PropTypes.number.isRequired,
    round_increment: PropTypes.number.isRequired,
    percent: PropTypes.number.isRequired
}

export default BuildingButton
