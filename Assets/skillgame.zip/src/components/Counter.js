/**
 * (c) Copyright 2017, Daniel Gilor, All Rights Reserved
 */
import React, { PropTypes } from 'react'

const Counter = ({ counter }) => (
    <div className="Counter">
        <p /> {counter.cash}
        <p /> Increment: {counter.increment}
    </div>
)

Counter.propTypes = {
    counter: PropTypes.shape({
        cash: PropTypes.number.isRequired,
        increment: PropTypes.number.isRequired
    }).isRequired
}

export default Counter
