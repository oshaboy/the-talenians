/**
 * (c) Copyright 2017, Daniel Gilor, All Rights Reserved
 */
import React, { PropTypes } from 'react'

const SkillButton = ({ onClick, id, selected, cost, enabled }) => (
    <label>
        <input
            type="checkbox"
            value={id}
            checked={selected}
            onChange={onClick}
            disabled={enabled ? '' : 'true'}
        />
        {id} Cost={cost}
    <br />
    </label>
)

SkillButton.propTypes = {
    onClick: PropTypes.func.isRequired,
    id: PropTypes.string.isRequired,
    selected: PropTypes.bool.isRequired,
    cost: PropTypes.number.isRequired,
    enabled: PropTypes.bool.isRequired
}

export default SkillButton
