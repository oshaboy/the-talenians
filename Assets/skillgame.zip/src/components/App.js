/**
 * (c) Copyright 2017, Daniel Gilor, All Rights Reserved
 */
import React, { Component } from 'react';
//import logo from './logo.svg';
import '../App.css';
import ActiveCounter from '../containers/ActiveCounter.js'
import ActiveBuilding from '../containers/ActiveBuilding'
import ActiveSkill from '../containers/ActiveSkill'

class App extends Component {
    render() {
        return (
            <div className="App">
                <div className="App-header">
                    {/* <img src={logo} className="App-logo" alt="logo" /> */}
                    <h2>Welcome to SkillGame</h2>
                </div>
                <div className="ActiveCounter">
                    <ActiveCounter />
                </div>
                <div className="ActiveBuilding">
                    <ActiveBuilding />
                </div>
                <div className="ActiveSkill">
                    <ActiveSkill />
                </div>
            </div>
        );
    }
}

export default App;
