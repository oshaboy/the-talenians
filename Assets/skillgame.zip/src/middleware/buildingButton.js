/**
 * (c) Copyright 2017, Daniel Gilor, All Rights Reserved
 */
import { buildingIncrementCount, counterDeductCost, counterSetIncrement, buildingSetIncrement } from '../actions/actionTypes'
import { calculateIncrement } from './timer.js'
import { findIndexForId } from '../reducers/building.js'
import { PLAIN_BUILDING, MULTIPLY_INCREASE_BUILDING, ADD_INCREASE_BUILDING } from '../reducers/skill.js'

export function buildingButtonPressed(id)
{
    console.log('buildingButtonPressed with id ' + id);
    return (dispatch, getState) => {
        // We need two pieces of the state
        let building = getState().building;
        let counter = getState().counter;

        let index = findIndexForId(building, id);

        // See if we have enough money to press the button
        let round_cost = building[index].round_cost;
        if (round_cost > counter.cash) {
            // Sorry, you can't do this
            return;
        }

        // Reduce the cash
        dispatch(counterDeductCost(round_cost));
        // Add one to the count
        dispatch(buildingIncrementCount(id));

        // If this is a special button, we change the plain building
        let plainIndex = findIndexForId(building, PLAIN_BUILDING);
        switch (id) {
            case MULTIPLY_INCREASE_BUILDING:
                dispatch(buildingSetIncrement(MULTIPLY_INCREASE_BUILDING, building[index].increment *
                    (100 + building[index].increment_percent) / 100));
                break;
            case ADD_INCREASE_BUILDING:
                dispatch(buildingSetIncrement(PLAIN_BUILDING, building[plainIndex].increment +
                    building[plainIndex].base_increment * building[index].increment_percent / 100));
                break;
            default:
                break;
        }

        // Calculate the new increment
        let incrementData = calculateIncrement(building);

        // And set it
        dispatch(counterSetIncrement(incrementData.total));
    }
}
