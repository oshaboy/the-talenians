/**
 * (c) Copyright 2017, Daniel Gilor, All Rights Reserved
 */
import { skillSelected, counterDeductCost } from '../actions/actionTypes'
import { findBuildingForSkill, findIndexForId } from '../reducers/skill'

export function skillButtonPressed(id)
{
    console.log('skillButtonPressed with id ' + id);
    return (dispatch, getState) => {
        // We need two pieces of the state
        let counter = getState().counter;
        let skill = getState().skill;
        let index = findIndexForId(id);

        // See if we have enough money to press the button
        let cost = skill[index].cost;
        if (cost > counter.cash) {
            // Sorry, you can't do this
            return;
        }

        // Is the skill disabled or selected
        if (skill[index].selected || !skill[index].enabled) {
            return;
        }

        // Reduce the cash
        dispatch(counterDeductCost(cost));
        // Go select it
        dispatch(skillSelected(id));
        // Figure out the building to create
        let buildingAction = findBuildingForSkill(id);
        if (typeof buildingAction === 'undefined') {
            return;
        }
        // And dispatch it
        dispatch(buildingAction);
    }
}
