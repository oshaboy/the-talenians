/**
 * (c) Copyright 2017, Daniel Gilor, All Rights Reserved
 */
import { counterCashBump, buildingSetContributionPercent, buildingIncrementContribution, counterSetIncrement } from '../actions/actionTypes'
import { roundDecimal } from '../reducers/building'

export function calculateIncrement(building)
{
    let contributions = [];
    let total = 0;
    for (var id = 0; id < building.length; id++) {
        let increment = building[id].count * building[id].round_increment;
        contributions.push(increment);
        total += increment;
    }
    return {
        total : roundDecimal(total, 2),
        contributions : contributions
    }
}

function calculateCash(totalIncrement, timeDiff)
{
    return (totalIncrement * timeDiff) / 1000;
}

export function timePassed()
{
    return (dispatch, getState) => {
        // We need the two pieces of the state
        let building = getState().building;
        let counter = getState().counter;

        // Tick calculation
        let currentTickCount = (new Date()).getTime();
        let lastTickCount = counter.previous_tick;

        if (lastTickCount === 0) {
            // No update, make believe one second passed
            lastTickCount = currentTickCount - 1000;
        }

        // Call the functions to calculate the data
        let incrementData = calculateIncrement(building);
        let cashAdd = calculateCash(incrementData.total, currentTickCount - lastTickCount);

        // Set the increment in case it wasn't right
        dispatch(counterSetIncrement(incrementData.total));

        // And dispatch the information
        dispatch(counterCashBump(cashAdd, currentTickCount));
        if (incrementData.total !== 0) {
            for (var i = 0; i < building.length; i++) {
                // We calculate the percentage first so we don't worry whether the increment already happened
                dispatch(buildingSetContributionPercent(building[i].id,
                    incrementData.contributions[i] * 100 / cashAdd));
                dispatch(buildingIncrementContribution(building[i].id, incrementData.contributions[i]));
            }
        }
    }
}
