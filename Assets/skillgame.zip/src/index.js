/**
 * (c) Copyright 2017, Daniel Gilor, All Rights Reserved
 */
import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux'
import { createStore, applyMiddleware } from 'redux'
import thunk from 'redux-thunk'
import skillApp from './reducers'
import App from './components/App';
import './index.css';
import { timePassed } from './middleware/timer'

console.log('Starting up');

// Start up the store
let store = createStore(skillApp, applyMiddleware(thunk))
console.log(store.getState());

// Subscribe to it so we can see all the changes
// Note that subscribe() returns a function for unregistering the listener
/* let unsubscribe = */ store.subscribe(() =>
    console.log(store.getState())
)

setInterval(() => store.dispatch(timePassed()), 1000);

ReactDOM.render(
    <Provider store={store}>
        <App />
    </Provider>,
    document.getElementById('root')
);
