/**
 * (c) Copyright 2017, Daniel Gilor, All Rights Reserved
 */
import { connect } from 'react-redux'
import { buildingButtonPressed } from '../middleware/buildingButton'
import BuildingButtonList from '../components/BuildingButtonList'

const mapStateToProps = (state) => {
    return {
        building: state.building
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        onBuildingButtonClick: (id) => {
            dispatch(buildingButtonPressed(id))
        }
    }
}

const ActiveBuilding = connect(
  mapStateToProps,
  mapDispatchToProps
)(BuildingButtonList)

export default ActiveBuilding
