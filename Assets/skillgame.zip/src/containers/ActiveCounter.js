/**
 * (c) Copyright 2017, Daniel Gilor, All Rights Reserved
 */
import { connect } from 'react-redux'
import Counter from '../components/Counter'

const mapStateToProps = (state) => {
    return {
        counter: state.counter
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
    }
}

const ActiveCounter = connect(
  mapStateToProps,
  mapDispatchToProps
)(Counter)

export default ActiveCounter
