/**
 * (c) Copyright 2017, Daniel Gilor, All Rights Reserved
 */
import { connect } from 'react-redux'
import { skillButtonPressed } from '../middleware/skillButton'
import SkillButtonList from '../components/SkillButtonList'

const mapStateToProps = (state) => {
    return {
        skill: state.skill
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        onSkillButtonClick: (id) => {
            dispatch(skillButtonPressed(id))
        }
    }
}

const ActiveSkill = connect(
  mapStateToProps,
  mapDispatchToProps
)(SkillButtonList)

export default ActiveSkill
