/**
 * (c) Copyright 2017, Daniel Gilor, All Rights Reserved
 */
import { COUNTER_CASH_BUMP, COUNTER_SET_INCREMENT, COUNTER_DEDUCT_COST } from '../actions/actionTypes'

const initialState = {
    cash: 20,
    increment: 0,
    previous_tick: 0
}

/**
 * Handles a tick
 */
function counter(state = initialState, action)
{
    switch (action.type) {
        case COUNTER_CASH_BUMP:
            return Object.assign({}, state, {
                cash: Math.round(state.cash + action.cashIncrement),
                previous_tick: action.newTick
            });
        case COUNTER_SET_INCREMENT:
            return Object.assign({}, state, {
                increment: action.increment
            });
        case COUNTER_DEDUCT_COST:
            return Object.assign({}, state, {
                cash: Math.round(state.cash - action.cost)
            });
        default:
            return state;
    }
}

export default counter;
