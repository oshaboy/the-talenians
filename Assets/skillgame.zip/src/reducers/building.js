/**
 * (c) Copyright 2017, Daniel Gilor, All Rights Reserved
 */
import { BUILDING_INCREMENT_COUNT, BUILDING_ADD_BUTTON, BUILDING_SET_BUTTON, BUILDING_SET_INCREMENT,
    BUILDING_INCREMENT_CONTRIBUTION, BUILDING_SET_CONTRIBUTION_PERCENT } from '../actions/actionTypes'

// Pressing a button in "building" will cause that "item" in the list to get one count added
function button(state = {}, action) {
    switch (action.type) {
        case BUILDING_INCREMENT_COUNT:
            if (state.id !== action.id) {
                return state;
            }
            // Add one to the count
            return Object.assign({}, state, {
                count: state.count + 1,
                cost: state.cost * 1.15,
                round_cost: Math.round(state.cost * 1.15)
            });
        case BUILDING_ADD_BUTTON:
            // Initial state
            return {
                id: action.id,
                count: 0,
                cost: action.cost,
                round_cost: Math.round(action.cost),
                base_increment: action.increment,
                increment: action.increment,
                round_increment: roundDecimal(action.increment, 2),
                increment_percent: action.increment_percent,
                contribution: 0,
                percent: 0
            };
        case BUILDING_SET_BUTTON:
            if (state.id !== action.id) {
                return state;
            }
            // We can only change the cost and the increment
            return Object.assign({}, state, {
                cost: action.cost,
                round_cost: Math.round(action.cost),
                increment: action.increment,
                round_increment: roundDecimal(action.increment, 2),
                increment_percent: action.increment_percent
            });
        case BUILDING_SET_INCREMENT:
            if (state.id !== action.id) {
                return state;
            }
            // We only change the increment
            return Object.assign({}, state, {
                increment: action.increment,
                round_increment: roundDecimal(action.increment, 2)
            });
        case BUILDING_INCREMENT_CONTRIBUTION:
            if (state.id !== action.id) {
                return state;
            }
            // Add one to the count
            return Object.assign({}, state, {
                contribution: state.contribution + action.contributionIncrement
            });
        case BUILDING_SET_CONTRIBUTION_PERCENT:
            if (state.id !== action.id) {
                return state;
            }

            // Add one to the count
            return Object.assign({}, state, {
                percent: Math.round(action.percent)
            });
        default:
            return state;
    }
}

// Pressing a button in "building" will cause that "item" in the list to get one count added
function building(state = [ ], action) {
    switch (action.type) {
        case BUILDING_ADD_BUTTON:
        return [
            ...state,
            button(undefined, action)
        ]
        default:
            return state.map(singleState =>
                button(singleState, action)
            );
    }
}

export default building;

export function findIndexForId(building, id)
{
    for (var i = 0; i < building.length; i++) {
        if (building[i].id === id) {
            return i;
        }
    }
    return -1;
}

export function roundDecimal(number, digits)
{
    let power = Math.pow(10, digits);
    return Math.round(number * power) / power;
}
