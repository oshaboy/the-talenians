/**
 * (c) Copyright 2017, Daniel Gilor, All Rights Reserved
 */
import { SKILL_SELECTED, buildingAddButton } from '../actions/actionTypes'

export const PLAIN_BUILDING = 'PlainBuilding';
export const MULTIPLY_INCREASE_BUILDING = 'MultiplyIncreaseBuilding';
export const ADD_INCREASE_BUILDING = 'AddIncreaseBuilding';

const initialState = [
    {
        id: PLAIN_BUILDING,
        selected: false,
        cost: 10,
        enabled: true
    },
    {
        id: MULTIPLY_INCREASE_BUILDING,
        selected: false,
        cost: 10,
        enabled: false
    },
    {
        id: ADD_INCREASE_BUILDING,
        selected: false,
        cost: 10,
        enabled: false
    }
]

export function findBuildingForSkill(id)
{
    switch (id) {
        case PLAIN_BUILDING:
            return buildingAddButton(PLAIN_BUILDING, 10, 1, 0);
        case MULTIPLY_INCREASE_BUILDING:
            return buildingAddButton(MULTIPLY_INCREASE_BUILDING, 200, 5, 10);      // Missing multiply
        case ADD_INCREASE_BUILDING:
            return buildingAddButton(ADD_INCREASE_BUILDING, 100, 0, 50);  // Missing multiply
        default:
            return;
    }
}

function checkEnabled(myId, hisId, oldEnabled)
{
    switch (hisId) {
        case PLAIN_BUILDING:
            switch (myId) {
                case MULTIPLY_INCREASE_BUILDING:
                case ADD_INCREASE_BUILDING:
                    return true;
                default:
                    return oldEnabled;
            }
        case MULTIPLY_INCREASE_BUILDING:
            switch (myId) {
                case ADD_INCREASE_BUILDING:
                    return false;
                default:
                    return oldEnabled;
            }
        case ADD_INCREASE_BUILDING:
            switch (myId) {
                case MULTIPLY_INCREASE_BUILDING:
                    return false;
                default:
                    return oldEnabled;
            }
        default:
            return oldEnabled;
    }
}

export function findIndexForId(id)
{
    for (var i = 0; i < initialState.length; i++) {
        if (initialState[i].id === id) {
            return i;
        }
    }
    return -1;
}

// Pressing a button in "building" will cause that "item" in the list to get one count added
function button(state = {}, action) {
    switch (action.type) {
        case SKILL_SELECTED:
            // If it was selected already, don't change it
            if (state.selected) {
                return state;
            }
            // Is it us?
            if (state.id === action.id) {
                // Our button, all we do is mark it as selected and not enabled
                return Object.assign({}, state, {
                    selected: true,
                    enabled: false
                });
            } else {
                // Set enabled according to ids
                let enabled = checkEnabled(state.id, action.id, state.enabled);
                // And the cost goes up times 10
                return Object.assign({}, state, {
                    enabled: enabled,
                    cost: state.cost * 10
                });
            }
            // Add one to the count
        default:
            return state;
    }
}

// Pressing a button in "skill" will cause that "item" in the list to get one count added
function skill(state = initialState, action) {
    return state.map(singleState =>
        button(singleState, action)
    );
}

export default skill;
