/**
 * (c) Copyright 2017, Daniel Gilor, All Rights Reserved
 */
import { combineReducers } from 'redux'
import counter from './counter'
import building from './building'
import skill from './skill'

const skillApp = combineReducers({
    counter,
    building,
    skill
})

export default skillApp
