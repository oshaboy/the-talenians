#pragma strict
/*
TODO:
	Make jumps ineffictive on steep slopes
*/
public enum State {Jump, Fall, Stand};
var jumpButtons : KeyCode[];
var initialspeed : float;
private var speed : float;
var maxHeight : float;
var floor : Transform;
private var heightJumped : float;
private var state : State;
private var isPressingJump : boolean  = false;
private var didPressJump : boolean;
//var : transform;

function getState(){
	return state;
}
function stringifyState(){
	if (state == State.Jump)
		return "Jump";
	if (state == State.Fall)
		return "Fall";
	if (state == State.Stand)
		return "Stand";
	Debug.LogError("Noam update Stringify State");
	return "Noam update Stringify State";
}
function Start () {
	speed = initialspeed;
	state = State.Stand;
	isPressingJump = false;
	didPressJump = isPressingJump;
}

/*function togglefinish(){
	didfinish = !didfinish;
}*/
function Update () {
	
	//check if pressing a jump button
	didPressJump = isPressingJump;
	isPressingJump = false;
	for (var jumpButton : KeyCode in jumpButtons){
		if (Input.GetKey(jumpButton))
		{
			isPressingJump = true;
			break;
		}
	}
	
	
	//comment this section later
	var otherwise = true;
	//if it touches floor
	if (floor.GetComponent(Floor).WhatFloorIsColliding(transform) != null){
		//reset jumping
		Debug.Log("hit floor");
		heightJumped = 0.0;
		//if landed
		if (state == State.Fall)
			state = State.Stand;
		//if hit
		if (state == State.Jump)
			state = State.Fall;
		//Debug.Log("hit floor");
		otherwise = false;

	}

	//if it is in air and jumping
	if ((heightJumped < maxHeight && isPressingJump) && (state != State.Fall && (!didPressJump || state == State.Jump)) ) {
		//move up
		transform.position += Vector3(0, speed * Time.deltaTime, 0);
		heightJumped += speed * Time.deltaTime;
		//Debug.Log("jumping");
		otherwise = false;
		state = State.Jump;
		Debug.Log("jumping");
		
	}
	else {
		//move down
		transform.position -= Vector3(0, speed * Time.deltaTime, 0);
		//Debug.Log(speed);
		if (state != State.Stand){
			state = State.Fall;
			//Debug.Log(speed * Time.deltaTime);
			Debug.Log("falling");
		}
	}

	/*
	//jump
	transform.position += Vector3(0, speed * Time.deltaTime, 0);
	heightJumped += speed * Time.deltaTime;
	Debug.Log("jump " + heightJumped);
	return;
	//if it is on floor
	if (floor.GetComponent(Floor).IsColliding(transform))
		heightJumped = 0.0;
	//if isn't on floor or is and not jumping
	else{
		transform.position -= Vector3(0, speed * Time.deltaTime, 0);
		Debug.Log("fall");
	}
	//fall
	*/
	
	
}

