#pragma strict



private var CameraPosition : Vector2 = Vector2(0,0);
private var lastMousePosition : Vector2 = Input.mousePosition; 
private var MouseSpeed : Vector2;
var radius:float;
var speed:float;
var character:GameObject;
var inputDevice:Library.InputDevice;
var scrollspeed;
private var MouseSlowdown = 1.0/Library.PixelsPerUnity;



function Start () {
	GetComponent.<Camera>().RenderWithShader(Shader.Find("MyShader"), "");
}

function LateUpdate () {
		
		//Calculate Mouse Speed by subtracting positions
		MouseSpeed = Input.mousePosition - lastMousePosition;
		//if the user is suing the keyboard
		if (inputDevice == Library.InputDevice.Keyboard) {
			//get the right thing
			if (Input.GetKey (KeyCode.DownArrow)){
				CameraPosition+=Vector2(0,1)*Time.deltaTime*speed;
			}
			if (Input.GetKey (KeyCode.UpArrow)){

				CameraPosition+=Vector2(0,-1)*Time.deltaTime*speed;
			}
			if (Input.GetKey (KeyCode.LeftArrow)){

				CameraPosition+=Vector2(-1,0)*Time.deltaTime*speed;
			}
			if (Input.GetKey (KeyCode.RightArrow)){

				CameraPosition+=Vector2(1,0)*Time.deltaTime*speed;
			}

		}
		//if the user is using the mouse
		else if (inputDevice == Library.InputDevice.Mouse){
			CameraPosition += MouseSpeed * speed / Library.PixelsPerUnity;
		}
		
		//radius -= Input.GetAxis("Mouse ScrollWheel") * speed;
		MoveCamera();
		
		//update the mouse position
		lastMousePosition = Input.mousePosition;
}

function MoveCamera(){
	/*var sinX = Mathf.Sin(CameraPosition.x);
	var sinY = Mathf.Sin(CameraPosition.y);
	var cosX = Mathf.Cos(CameraPosition.x);
	var cosY = Mathf.Cos(CameraPosition.y);*/
	var direction : Quaternion =  Quaternion.Euler(CameraPosition.y * Mathf.Rad2Deg,  CameraPosition.x * Mathf.Rad2Deg, 0) ;
	var distance : Vector3 = direction * Vector3.forward * radius;
	transform.position = character.transform.position + distance;
	
	transform.LookAt(character.transform);
}