﻿#pragma strict


//This is the script attached to every single floor tile
public var floor : Transform;
//private var collidedList : Array;
private var collisions : Array = Array();
///private var collidedSpeeds : Array;

function Start(){
	//collidedList = new Array();
	//collisions = new Collision[];
	Library.doAbsolutelyNothing();
}

function get Collisions() : Array{
	return collisions;
}
function OnCollisionEnter(collision: Collision){
	if (transform.name == "Cube")
		Debug.Log("Cube");
	Debug.Log("collided");
	//collidedList.Push(collision.collider.transform);
	collisions.Add(collision);
	//collision.collider.transform.GetComponent(Jump).togglefinish();

}



function getCollision(t :Transform){
	for (var collision : Collision in collisions)
		if (collision.collider.transform == t)
			return collision;
			
	return null;
}
function collisionCompare(collision1 : Collision, collision2 : Collision) {
	return collision1.collider.transform == collision2.collider.transform;
}
function OnCollisionExit(collision: Collision){
	//collidedList.Remove(collision.collider.transform);
	collisions.Remove(getCollision(collision.collider.transform));
	Debug.Log("exited");
}

function Update(){
	for (var collision : Collision in Collisions){
		//find the normal of the median point and add a force away from there
		var contacts = collision.contacts;
		Debug.Log("collision");
		var normal = Library.getAvrgNormal(collision);
		Debug.Log(normal);
		collision.collider.transform.position -= normal * floor.GetComponent(Floor).resistance * Time.deltaTime;
		Debug.Log(collision);

	}
}
function isCollided (t : Transform) : boolean{

	var f = function(x,y) {
		var c:Collision = x as Collision;
		return c.collider.transform == y;
	};
	return (Library.Index(Collisions, t, f) != -1);
}

//get the normal of a collision;
function GetContactPoints (t : Transform) {
	return getCollision(t).contacts;

}
