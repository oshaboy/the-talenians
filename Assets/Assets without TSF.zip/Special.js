﻿#pragma strict

public class Special{
	public var wait : float;
	public var time : float;
	public var isActing : boolean = false;
	var character : Transform;
	public function act() {
		
		
	}
	public function stop() {
		
	}
	public function Special (c : Transform) {
		character = c;
	}
}