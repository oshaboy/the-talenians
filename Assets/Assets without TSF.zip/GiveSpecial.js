﻿#pragma strict

enum CharacterClass{Sportman ,SwordFighter};

private var special : Special;
var SpecialKeys : KeyCode[];
var isToggle : boolean;

var charClass : CharacterClass;


function Start(){
	special = new Special(transform);
	switch(charClass){
		case CharacterClass.Sportman:
			special.wait = 1;
			special.time = 10;
			special.act function() {
				transform.GetComponent(BasicMovements).BuffSpeed(1.5);
				//script.BuffSpeed(1.5);
				//character.GetComponent(BasicMovements).airspeed  *= 1.5;
			};
			special.stop function() {
				
			};
			break;
		case SwordFighter:

			break;
	}
}
function Update (){
	if(isToggle){
		for (var key : KeyCode in SpecialKeys)
			if (Input.GetKeyUp(key)){
				special.isActing = (special.isActing ? special.stop : special.act)();
			}
	}
	else{
		for (var key : KeyCode in SpecialKeys)
			if (Input.GetKey(key)){
				
				special.act();
			}
			else if (!Input.GetKey(key)){
				
				special.stop();;
			}
	}

}