﻿#pragma strict
public class Library
{
	enum InputDevice {Mouse, Keyboard};
	static var PixelsPerUnity = 100.0; //find exact number when less tired
	public static function diagonal(sides:float[]){
		//var args = Array.prototype.slice.call(arguments, 0);
		var sumOfSquares : float=0;
		for (var side in sides)
			sumOfSquares += side*side;
		return Mathf.Sqrt(sumOfSquares);
	}
	public static function sign(x : float){
		if (x==0) return 0;
		if (x>0) return 1;
		else return -1;
	}
	
	public static function Log2(exponent : float){
		return Mathf.Log(exponent, 2);
	}
	
	public static function Index(array :Array, x, compare : function(Object, Object) : boolean) {
		for (var i = 0; i<array.length; i++){
			var bool = compare(array[i],x);
			if (bool)
				return i;
		}
		return -1;
	}
	public static function average(array : float[]){
		var sum = 0.0;
		for (var num : float in array){
			sum += num;
		}
		return sum / array.length;
	}
	public static function average(array : Vector3[]){
		var sum = new Vector3(0.0,0.0,0.0);
		Debug.Log(array);
		for (var vect : Vector3 in array){
			sum += vect;
		}
		return sum / array.length;
	}
	
	public static function doAbsolutelyNothing(){
		;
	}

	public static function AllChildren(ancestor : Transform){
		var output = new Array();
		AllChildrenRec(output, ancestor);
		return output;
	}
	private static function AllChildrenRec(output : Array, ancestor : Transform){
		output.Push(ancestor);
		for (var i = 0; i<ancestor.childCount; i++){
			AllChildrenRec(output, ancestor.GetChild(i));
			/*bla bla test debugger
			did the debugger completly break the error recognition*/
			/*you do it for her
			and then you do it again
			you do it for her that is to say
			you do it for him*/
		}

	}

	static function getAvrgNormal(c : Collision) : Vector3{
		var normalArray : Vector3[] = new Vector3[c.contacts.length];
		for(var i = 0; i<c.contacts.length ;i++){
			normalArray[i] = c.contacts[i].normal;
		}

		return Library.average(normalArray);
			
	}



		/*private static getCollisionVectors(c : Collision) : Vector3{
		var arr : Vector3[] = [];
		for(var point : ContactPoint in c.contacts)
			
	}



	/*public static function toBool(x){
		if (x.is(boolean))
			return x as boolean;
		if (x.is(Integer))
			return x != 0;
		if (x.is(Array))
			return x.Length != 0;
		if (x.is(double) || x.is(float))
			return x != NaN;

		return x != null;
	}
	/*public static function RemoveFromArray(x, array : Array){
		var index = array.Remove(
		if (index == -1) return false;
		array.slice(index, index);
		return true;
	}*.
	
	/*public class Queue{
		
	}*/

	/*
	DEPRACATED, use Mathf.deg2rad and Mathf.rad2deg instad
	public static final var rad = 180 / Mathf.PI;
	public static final var deg =  Mathf.PI/180;
	*/
}

	