#pragma strict
	var left : KeyCode[];
	var right : KeyCode[];
	var up : KeyCode[];
	var down : KeyCode[];
	var thirdPersonCamera : Camera;
	public var floorspeed : float;
	public var airspeed : float;
	public var scaleHeight : float;
	private var scaleHeightAsVector : Vector3;
function Start () {
	scaleHeightAsVector = new Vector3(0,scaleHeight,0);
}

function BuffSpeed(amount : float){
	airspeed *=amount;
	floorspeed *= amount;
}
function Walk(direction : Vector3) {
	direction.y = 0;
	//get the floor the player is colliding with
	var TheFloor : Transform = Globals.transformTable["Floor"] as Transform;
	var floorscript = TheFloor.GetComponent(Floor);
	var currentFloorPlayerIsHitting = floorscript.WhatFloorIsColliding(transform);


	if (currentFloorPlayerIsHitting != null){ //if it is hitting a floor

		/*
		find if the next position can be scaled and move the y position there
		*/
		var futureposition = transform.position + direction*floorspeed*Time.deltaTime; 
		var ray : Ray = new Ray(futureposition, Vector3.up);
		var hit : RaycastHit;
		Debug.Log(transform.GetComponent(Jump).stringifyState());
		if (Physics.Raycast(ray, hit)){ //if the floor is higher than the player

			if (hit.transform.Equals(currentFloorPlayerIsHitting)){ //if it is the same floor currently stood on
				if (hit.point.y - futureposition.y > scaleHeight){
				Debug.Log("too High");
				
				return;
				}
				Debug.Log("good");
				Debug.Log(futureposition.y);
				Debug.Log(hit.point.y);
				futureposition.y = hit.point.y + transform.GetComponent.<Collider>().bounds.size.y/2; //move the y axis there
				var x= 0;
			}
		}
		//Debug.Log("Fall");

		transform.position = futureposition;
	}
	else {
		Debug.Log("Air");
		transform.position += direction*Time.deltaTime*airspeed;
	}
	
	
}

function Update () {
		var scr : Jump = transform.GetComponent(Jump);
		var speed = (scr.stringifyState() == "Stand" ? floorspeed : airspeed); //i like shorthand ifs
		var typeOfSpeed = (scr.stringifyState() == "Stand" ? "floorspeed" : "airspeed"); //i like shorthand ifs
		Debug.Log(scr.stringifyState());
		var direction : Vector3 = Vector3.zero;
			for (var key : KeyCode in left) {
				if (Input.GetKey (key)){
					Debug.Log("left is pressed with key " + key);
					direction = thirdPersonCamera.transform.rotation * (Vector3.left); //checks where is left relative to the camera					
					//make sure player doesn't walk through the floor 


 //moves it there
					break;
				}
			}
			for (var key : KeyCode in right) { 
				if (Input.GetKey (key)){
					Debug.Log("right is pressed with key " + key);
					direction = thirdPersonCamera.transform.rotation * (Vector3.right); ////checks where is right relative to the camera					
					//make sure player doesn't walk through the floor 
					//direction.y=0;
					//Walk(direction);
					break;
				}
			}
			for (var key : KeyCode in up) {
				if (Input.GetKey (key)){
					Debug.Log("up is pressed with key " + key);
					direction += thirdPersonCamera.transform.rotation * (Vector3.forward); ////checks where is up relative to the camera
					//make sure player doesn't walk through the floor 
					//direction.y=0;
					//Walk(direction);
					break;
				}
			}
			for (var key : KeyCode in down) { 
				if (Input.GetKey (key)){
					Debug.Log("down is pressed with key " + key);
					direction += thirdPersonCamera.transform.rotation * (-Vector3.forward);
					//make sure player doesn't walk through the floor 
					//Walk(direction);
					break;
				}
			}
			Debug.Log(typeOfSpeed);
			Walk(direction);

}